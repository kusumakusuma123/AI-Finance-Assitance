import streamlit as st
import numpy as np
import joblib
import pandas as pd

# ------------------ UI TITLE ------------------
st.title("💰 Investment Recommendation System")
st.write("Enter your financial details below:")

# ------------------ INPUTS ------------------
age = st.slider("Age", 18, 70)

income = st.number_input("Monthly Income", min_value=0)
savings_rate = st.slider("Savings Rate", 0.0, 1.0)

debt = st.number_input("Debt")

housing = st.number_input("Housing Expense")
food = st.number_input("Food Expense")
transport = st.number_input("Transport Expense")
entertainment = st.number_input("Entertainment Expense")
shopping = st.number_input("Shopping Expense")
healthcare = st.number_input("Healthcare Expense")

credit_card = st.selectbox("Credit Card Usage", ["Low", "Medium", "High"])
stress = st.selectbox("Financial Stress", ["Low", "Medium", "High"])
health_score = st.number_input("Financial Health Score")

# ------------------ CONVERT CATEGORICAL ------------------
cc_map = {"Low": 0, "Medium": 1, "High": 2}
stress_map = {"Low": 0, "Medium": 1, "High": 2}

credit_card = cc_map[credit_card]
stress = stress_map[stress]

# ------------------ LOAD MODELS ------------------
kmeans = joblib.load("models/kmeans.pkl")
scaler = joblib.load("models/scaler.pkl")

# ------------------ DYNAMIC PORTFOLIO FUNCTION ------------------
def dynamic_portfolio(risk, savings_rate, health_score):

    # Base allocation
    if risk == "Conservative":
        stocks, bonds, mutual_funds, gold = 10, 50, 25, 15

    elif risk == "Moderate":
        stocks, bonds, mutual_funds, gold = 30, 25, 30, 15

    else:  # Aggressive
        stocks, bonds, mutual_funds, gold = 50, 10, 25, 15

    # Adjust based on savings rate
    if savings_rate > 0.4:
        stocks += 10
        bonds -= 5
    elif savings_rate < 0.2:
        stocks -= 10
        bonds += 10

    # Adjust based on financial health
    if health_score > 25:
        stocks += 5
        mutual_funds += 5
    elif health_score < 15:
        bonds += 5
        gold += 5

    # Normalize to 100%
    total = stocks + bonds + mutual_funds + gold

    stocks = round((stocks / total) * 100)
    bonds = round((bonds / total) * 100)
    mutual_funds = round((mutual_funds / total) * 100)
    gold = round((gold / total) * 100)

    return {
        "Stocks": stocks,
        "Mutual Funds": mutual_funds,
        "Bonds": bonds,
        "Gold": gold
    }

# ------------------ BUTTON ACTION ------------------
if st.button("Get Recommendation"):

    columns = [
        'age', 'monthly_income', 'savings_rate', 'debt',
        'housing_expense', 'food_expense', 'transport_expense',
        'entertainment_expense', 'shopping_expense',
        'healthcare_expense', 'credit_card_usage',
        'financial_stress', 'financial_health_score'
    ]

    input_df = pd.DataFrame([[
        age, income, savings_rate, debt,
        housing, food, transport,
        entertainment, shopping, healthcare,
        credit_card, stress, health_score
    ]], columns=columns)

    # Scale input
    scaled_input = scaler.transform(input_df)

    # Predict cluster
    cluster = kmeans.predict(scaled_input)[0]

    # Map to risk
    cluster_map = {
        0: "Moderate",
        1: "Aggressive",
        2: "Conservative"
    }
    st.write("Predicted Cluster:", cluster)
    risk = cluster_map[cluster]

    # Get portfolio
    portfolio = dynamic_portfolio(risk, savings_rate, health_score)

    # ------------------ OUTPUT ------------------
    st.subheader("📊 Results")

    st.write(f"**Risk Profile:** {risk}")

    st.write("**Recommended Portfolio Allocation:**")
    st.write(portfolio)

    # Chart
    st.bar_chart(portfolio)

    # Extra insights
    st.write("📈 Expected Return: 10–12%")
    st.write("💡 Suggested SIP: ₹10,000/month")